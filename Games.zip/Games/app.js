const express = require('express');
const sequelize = require('./configuracoes/DBGames');
const Game = require('./models/Game'); 

const app = express();
app.use(express.json());

sequelize.sync().then(() => {
  console.log('Banco de dados sincronizado');
}).catch(err => {
  console.error('Erro ao sincronizar o banco de dados:', err);
});

app.post('/Games', async (req, res) => {
  const { nome, genero, plataforma, preco } = req.body;
  try {
    const newGame = await Game.create({ nome, genero, plataforma, preco });
    res.status(201).json(newGame);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar jogo' });
  }
});

app.get('/Games', async (req, res) => {
  try {
    const games = await Game.findAll();
    res.status(200).json(games);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar jogos' });
  }
});

app.put('/Games/:id', async (req, res) => {
    const { id } = req.params;  
    const { nome, genero, plataforma, preco } = req.body;  
  
    try {
      const game = await Game.findByPk(id);
  
      if (!game) {
        return res.status(404).json({ error: 'Jogo não encontrado' });
      }
  
      game.nome = nome;
      game.genero = genero;
      game.plataforma = plataforma;
      game.preco = preco;
  
      await game.save();
  
      res.status(200).json(game);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Erro ao atualizar jogo' });
    }
  });  

  app.get('/Games/:id', async (req, res) => {
    const { id } = req.params; 
    
    try {
      const game = await Game.findByPk(id);
  
      if (!game) {
        return res.status(404).json({ error: 'Jogo não encontrado' });
      }
  
      res.status(200).json(game);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Erro ao buscar jogo' });
    }
  });

  app.delete('/Games/:id', async (req, res) => {
    const { id } = req.params; 
  
    try {
      const game = await Game.findByPk(id);
  
      if (!game) {
        return res.status(404).json({ error: 'Jogo não encontrado' });
      }
  
      await game.destroy();
  
      res.status(200).json({ message: 'Jogo excluído com sucesso' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Erro ao excluir jogo' });
    }
  });
  

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

